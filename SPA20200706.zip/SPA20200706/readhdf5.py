import numpy as np
import h5py
import matplotlib.pyplot as plt
import scipy.constants as scpc


coeff = (scpc.e**2)/(6.0*scpc.pi*scpc.epsilon_0*(scpc.c**3))

with h5py.File('./Particles/fftResult.hdf5', 'r') as f:
#   data = f['dataset']
#   print(min(data))
#   print(max(data))
#   print(data[:15]) 
    freq = f['freq']
    with h5py.File('./Particles/FinalResultArchive.hdf5', 'w') as archive:
        archive_dset = archive.create_dataset('freq', (len(freq),), dtype=freq.dtype,data=freq, compression="gzip", compression_opts=4)
#    TotFFTData = np.zeros(len(freq))
    TotFFTDataWABS = np.zeros(len(freq))
    for group in f.keys():
       print(group)
       if group == 'freq':
           pass
       else:
           radlos = np.zeros(len(freq))
           for dset in f[group].keys():
               radlos = radlos+np.abs(f[group][dset][:])**2
           radlos = coeff*radlos
           with h5py.File('./Particles/FinalResultArchive.hdf5', 'a') as archive:
               archive_dset = archive.create_dataset(group, (len(radlos),), dtype=radlos.dtype,data=radlos, compression="gzip", compression_opts=4)
           plt.plot(freq,radlos)
           plt.xscale('log')
           plt.yscale('log')
           plt.xlabel('Freuency (Hz)')
           plt.ylabel(r'I($\omega$)')
           plt.savefig("./Plots/"+group+'.png',dpi=600)
           plt.close()
       #if key == 'freq':
           #pass
       ##elif key == 'dataset_1':
           ##pass
       ##elif key == 'dataset_13':
           ##pass
       ##elif key == 'dataset_25':
           ##pass
       #else:
           #data = f[key]
##           TotFFTData = data+TotFFTData
           #TotFFTDataWABS = np.abs(data)**2+TotFFTDataWABS 
           #plt.plot(freq,np.abs(data)**2)
           #plt.xscale('log')
           #plt.yscale('log')
           #plt.savefig(key+'.png', dpi = 600)
           #plt.close()
##           plt.show()
##    plt.plot(freq,np.abs(TotFFTData)**2)
    #plt.plot(freq,np.abs(TotFFTDataWABS))
    #plt.xscale('log')
    #plt.yscale('log')
    #plt.savefig('Tots.png', dpi = 600)
    #plt.show()
