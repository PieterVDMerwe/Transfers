import numpy as np
import matplotlib.pyplot as plt
import pandas as pd 
import h5py
#from scipy.fftpack import fft, rfft, irfft, fftfreq, fftshift
import scipy.constants as scicon

import pyfftw
from pyfftw.interfaces.scipy_fftpack import fft, rfft, irfft, fftfreq, fftshift



def file_len(fname):
    with open(fname) as f:
        for i, l in enumerate(f):
            pass
    return i + 1

parmFile = pd.read_csv("Parameter_file.csv");



dt = parmFile['dt'][0]
i_lim = parmFile['i_lim'][0]
numPart = parmFile['numPart'][0]

# Turn on the cache for optimum performance
pyfftw.interfaces.cache.enable()

with h5py.File("Particles/fftResult.hdf5",'w') as f:
    freq = fftfreq(i_lim,dt)
#    freq = fftshift(freq)
    d = f.create_dataset('freq', (len(freq[0:i_lim/2:128]),), dtype=freq.dtype,data=freq[:i_lim/2:128], compression="gzip", compression_opts=4)
    freq = None 
    del freq

#plt.ioff()
#fig1 = plt.figure()
#fig2 = plt.figure()
#
#ax1 = fig1.add_subplot(111)
#ax2 = fig2.add_subplot(111)

#time = np.arange(0.0,i_lim*dt,dt)

for j in range(0,numPart):
    with h5py.File("Particles/fftResult.hdf5",'a') as f:
        grp = f.create_group('Particle_'+str(j))
        for k in [0,1]:
            try:
                print("Starting particle: "+str(j))
            #    data = pd.read_csv("Particles/particle_"+str(j)+"_acceleration.txt", usecols=["radlos","t"]);
            #    dataTemp = np.loadtxt("Particles/particle_"+str(j)+"_acceleration.txt", usecols=1,delimiter=",",skiprows=1,dtype=np.float32)
            #    radlosPadded = np.zeros(i_lim)
                radlosPadded = pyfftw.zeros_aligned(i_lim)
                fileLen = np.fromfile("./Particles/particle_"+str(j)+"_File_Length.dat", dtype=np.intc)
                print(fileLen[0]+1)
                radlosPadded[:fileLen[0]+1] = np.fromfile("Particles/particle_"+str(j)+"_acceleration_element_"+str(k)+".dat", dtype=np.double)
                print("Entering loop")
            #    print(radlosPadded[:100])
            #    for k in range(0,len(data['radlos'])):
            #        radlosPadded[k] = data['radlos'][k]
                print(i_lim)
            #    print((len(dataTemp)))
            #    radlosPadded[0:(len(dataTemp))] = dataTemp
            #    dataTemp = None
            #    del dataTemp
                print("Starting FFT")
            #    radlosF = fft(radlosPadded, threads=8)
            #    fft(radlosPadded, threads=8, overwrite_x=True,auto_align_input=False)
                try:
                    radlosF = fft(radlosPadded, threads=8, auto_align_input=True)
                except:
                    print("Problems with FFT")
                radlosPadded = None
                del radlosPadded
        #        radlosF = fftshift(radlosF)
            #    radlosPadded = fftshift(radlosPadded)
            #    radlosPadded = np.abs(radlosPadded)**2
        #        with h5py.File("Particles/particle_"+str(j)+"_fftResult.hdf5",'a') as f:
                with h5py.File("Particles/fftResult.hdf5",'a') as f:
            #        d = f.create_dataset('dataset', (i_lim,), dtype=radlosPadded.dtype,data=radlosPadded)
                    d = grp.create_dataset('dataset_'+str(j)+'_component_'+str(k-1), (len(radlosF[0:i_lim/2:128]),), dtype=radlosF.dtype,data=radlosF[:i_lim/2:128], compression="gzip", compression_opts=4)

        #            d = f.create_dataset('dataset_'+str(j), (i_lim/128,), dtype=radlosF.dtype,data=radlosF[:i_lim:128], compression="gzip", compression_opts=4)
                    print(radlosF[0])
                    print(d[0])
            #        d[:] = radlosPadded
            #    radlosFSqr = np.abs(radlosF[i_lim/2:])**2
                radlosF = None
                del radlosF
            #    temp = np.array([freq[i_lim/2:], radlosFSqr])
            #    np.savetxt("Particles/particle_"+str(j)+"_fftResult.txt",temp.T)
            #    np.savetxt("Particles/particle_"+str(j)+"_fftResult.txt",radlosPadded.T)
                
            #    ax1.clear()
            #    ax1.plot(time,np.log10(radlosPadded))
            #    ax1.set_ylabel(r"Log(Energy loss (joule/s))")
            #    ax1.set_xlabel(r"Time (s)")
            #    #ax1.set_yscale('log')
            #    ax1.set_xscale('log')
            #    #upperLim = 10.0e-30
            #    #print(upperLim)
            #    #ax1.set_ylim(-42,-34)
            #    #plt.tight_layout()
            #    fig1.savefig("Radlos_"+str(j)+".png", dpi=300)
            #    
            #    ax2.clear()
            #    ax2.plot(freq,radlosFSqr)
            #    ax2.set_ylabel(r"Power (joule/s)")
            #    ax2.set_xlabel(r"Frequency (Hz)")
            #    ax2.set_yscale('log')
            #    ax2.set_xscale('log')
            #    #plt.tight_layout()
            #    fig2.savefig("FFT_"+str(j)+".png", dpi=300)
                
                
                print("Done with particle: "+str(j))+" Component: "+str(k)
            except:
                print("Something happened with particle"+str(j))+" Component: "+str(k)
            finally:
                if j == (numPart-1):
                    print("Done")
                else:
                    print("Continuing with next particle")

